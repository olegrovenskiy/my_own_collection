# Ansible Collection - my_own_collection.my_own_module

Documentation for the collection.
